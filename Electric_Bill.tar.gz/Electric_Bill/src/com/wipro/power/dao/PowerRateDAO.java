package com.wipro.power.dao;

import java.sql.*;

import com.wipro.power.bean.PowerRateBean;
import com.wipro.power.util.DBUtil;

public class PowerRateDAO {
	public PowerRateBean findRateByType(String type) {
		PowerRateBean bean = new PowerRateBean();
		try {
			Connection conn = DBUtil.getDBConnection();
			String sql = "SELECT * FROM POWER_RATE_TBL WHERE TYPE = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1,type);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				bean.setType(rs.getString(1));
				bean.setSlab1(rs.getInt(2));
				bean.setSlab2(rs.getInt(3));
				bean.setSlab3(rs.getInt(4));
				bean.setSlabRate1(rs.getFloat(5));
				bean.setSlabRate2(rs.getFloat(6));
				bean.setSlabRate3(rs.getFloat(7));
			}
		} catch (Exception e) {
			System.out.println("INVALID TYPE");
		}
		return bean;

	}
}

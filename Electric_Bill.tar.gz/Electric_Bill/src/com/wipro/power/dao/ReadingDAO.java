package com.wipro.power.dao;

import java.util.ArrayList;
import java.sql.*;

import com.wipro.power.bean.ReadingBean;
import com.wipro.power.util.DBUtil;

public class ReadingDAO {
	public String createReading(ReadingBean readingBean) {
		int n = 0;
		try {
			readingBean.setSerialNo(generateSerialNo());
			Connection con = DBUtil.getDBConnection();
			PreparedStatement pstmt = con.prepareStatement("INSERT INTO READINGS_TBL VALUES(?,?,?,?,?,?,?,?,?)");
			pstmt.setInt(1, readingBean.getSerialNo());
			pstmt.setString(2, readingBean.getAssetID());
			pstmt.setString(3, readingBean.getType());
			pstmt.setInt(4, readingBean.getPresentReading());
			pstmt.setInt(5, readingBean.getPastReading());
			pstmt.setString(6, readingBean.getBillMonth());
			pstmt.setString(7, readingBean.getBillYear());
			pstmt.setInt(8, readingBean.getUnitsUsed());
			pstmt.setFloat(9, readingBean.getAmount());
			n = pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}
		if (n == 1) {
			return "SUCCESS";
		} else {
			return "FAIL";
		}
	}

	public int generateSerialNo() {
		try {
			Connection con = DBUtil.getDBConnection();
			PreparedStatement pstmt = con.prepareStatement("SELECT RENTAL_SEQ.NEXTVAL from DUAL");
			ResultSet rset = pstmt.executeQuery();
			int value = 0;
			while (rset.next()) {
				value = rset.getInt(1);
			}
			return value;
		} catch (Exception e) {
			System.out.println(e);
		}
		return 0;

	}

	public ArrayList<ReadingBean> viewAllBillsByMonth(String month, String year) {
		ArrayList<ReadingBean> list = new ArrayList<>();
		try {
			Connection con = DBUtil.getDBConnection();
			Statement stmt = con.createStatement();
			ReadingBean bean = new ReadingBean();
			ResultSet rs = stmt.executeQuery(
					"SELECT * FROM READING_TBL WHERE BILLMONTH='" + month + "' AND BILLYEAR='" + year + "'");
			while (rs.next()) {
				bean.setSerialNo(rs.getInt(1));
				bean.setAssetID(rs.getString(2));
				bean.setType(rs.getString(3));
				bean.setPresentReading(rs.getInt(4));
				bean.setPastReading(rs.getInt(5));
				bean.setBillMonth(rs.getString(6));
				bean.setBillYear(rs.getString(7));
				bean.setUnitsUsed(rs.getInt(8));
				bean.setAmount(rs.getFloat(9));
				list.add(bean);
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}
}

package com.wipro.power.bean;


public class PowerRateBean {
	private String type;
	private int slab1;
	private int slab2;
	private int slab3;
	private float slabRate1;
	private float slabRate2;
	private float slabRate3;

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getSlab1() {
		return slab1;
	}
	public void setSlab1(int slab1) {
		this.slab1 = slab1;
	}
	public int getSlab2() {
		return slab2;
	}
	public void setSlab2(int slab2) {
		this.slab2 = slab2;
	}
	public int getSlab3() {
		return slab3;
	}
	public void setSlab3(int slab3) {
		this.slab3 = slab3;
	}
	public float getSlabRate1() {
		return slabRate1;
	}
	public void setSlabRate1(float slabRate1) {
		this.slabRate1 = slabRate1;
	}
	public float getSlabRate2() {
		return slabRate2;
	}
	public void setSlabRate2(float slabRate2) {
		this.slabRate2 = slabRate2;
	}
	public float getSlabRate3() {
		return slabRate3;
	}
	public void setSlabRate3(float slabRate3) {
		this.slabRate3 = slabRate3;
	}
	
}

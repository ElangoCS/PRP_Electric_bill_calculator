package com.wipro.power.util;
import java.sql.*;

public class DBUtil {
	public static Connection getDBConnection(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection(
					"jdbc:oracle:thin:@orcl.rmk.ac.in:1521:orcl","scott","tiger");
			if(connection!=null){
				return connection;
			}
		}
		catch(Exception e){
			System.out.println(e.toString());
		}
		return null;
	}
}
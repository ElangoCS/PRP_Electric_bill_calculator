package com.wipro.power.service;

import java.util.ArrayList;

import com.wipro.power.bean.PowerRateBean;
import com.wipro.power.bean.ReadingBean;
import com.wipro.power.dao.PowerRateDAO;
import com.wipro.power.dao.ReadingDAO;

public class PowerMain {
	public static void main(String[] args) {
		ReadingBean readingBean = new ReadingBean();
		readingBean.setAssetID("HO1122");
		readingBean.setPresentReading(320);
		readingBean.setPastReading(100);
		readingBean.setType("House");
		readingBean.setBillMonth("Feb");
		readingBean.setBillYear("2015");
		String result = new PowerMain().generateBill(readingBean);
		System.out.println(result);
		ArrayList<ReadingBean> bills = new PowerMain().viewAllBills("Feb", "2015");
		if (bills != null) {
			for (ReadingBean reading : bills) {
				System.out.println(reading.getSerialNo());
				System.out.println(reading.getAmount());
			}
		}
	}

	public float calculateAmount(int unitsUsed, String type) {
		PowerRateBean pb1 = new PowerRateBean();
		int slab1 = pb1.getSlab1();
		int slab2 = pb1.getSlab2();
		int slab3 = pb1.getSlab3();
		PowerRateDAO pdao = new PowerRateDAO();
		PowerRateBean pb = pdao.findRateByType(type);
		if (unitsUsed > slab1 && unitsUsed <= slab2) {
			return (unitsUsed * pb.getSlabRate1());
		} else if (unitsUsed > slab2 && unitsUsed <= slab3) {
			return ((slab2) * pb.getSlabRate2() + (unitsUsed - slab3) * pb.getSlabRate1());
		}
		return ((slab2) * pb.getSlabRate1()) + ((slab3 - slab2)) * pb.getSlabRate2()
				+ ((unitsUsed - slab3) * pb.getSlabRate3());
	}

	public String generateBill(ReadingBean readingBean) {
		if (readingBean.getType() == null || (readingBean.getPastReading() > readingBean.getPresentReading())) {
			return "INVALID";
		}
		if (readingBean.getType() != "Mall" && readingBean.getType() != "House" && readingBean.getType() != "Shop") {
			return "INVALID";
		}
		int unitsused = readingBean.getPresentReading() - readingBean.getPastReading();
		float amount = calculateAmount(unitsused, readingBean.getType());
		readingBean.setAmount(amount);
		readingBean.setUnitsUsed(unitsused);
		ReadingDAO obj = new ReadingDAO();
		String s = obj.createReading(readingBean);
		if (s == "FAIL") {
			return "FAIL";
		} else {
			return "Amount:" + amount;
		}

	}

	public ArrayList<ReadingBean> viewAllBills(String month, String year) {

		return new ReadingDAO().viewAllBillsByMonth(month, year);

	}
}
